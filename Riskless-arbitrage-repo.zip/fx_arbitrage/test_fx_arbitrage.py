"""Run:  python -m pytest test_fx_arbitrage.py   (or simply  python test_fx_arbitrage.py)"""
import math
import fx_arbitrage as fx


def test_textbook_cirp_example():
    # CFA-style: S = 1.2000 USD/EUR, i_USD 4%, i_EUR 2%, 1 year, both /360 with 360 days
    m = fx.MarketInputs("EUR/USD", 360, 1.20, 1.20, 0.02, 0.04, 360, 360)
    assert math.isclose(fx.implied_forward(m), 1.20 * 1.04 / 1.02)


def test_higher_rate_currency_at_discount():
    m = fx.MarketInputs("USD/JPY", 91, 160.0, 160.0, 0.038, 0.0105)
    assert fx.implied_forward(m) < m.spot_mid            # USD (higher rate) at forward discount


def test_gross_profit_identity_and_direction():
    m = fx.MarketInputs("EUR/USD", 91, 1.16, 1.16, 0.022, 0.038)
    m.fwd_mid = fx.implied_forward(m) + 0.0003
    p = fx.analyse_parity(m)
    assert p.direction == "borrow_quote"
    pnl = fx.trade_pnl(m, fx.CostInputs(), "borrow_quote")
    assert math.isclose(pnl["gross"], pnl["fx_principal"] + pnl["i_earn"] - pnl["i_pay"], abs_tol=1e-12)
    assert pnl["gross"] > 0
    # the wrong direction must lose money by symmetry
    assert fx.trade_pnl(m, fx.CostInputs(), "borrow_base")["gross"] < 0


def test_at_parity_no_arbitrage_either_way():
    m = fx.MarketInputs("GBP/USD", 91, 1.35, 0.0, 0.037, 0.038, 365, 360)
    m.fwd_mid = fx.implied_forward(m)
    for d in ("borrow_quote", "borrow_base"):
        assert abs(fx.trade_pnl(m, fx.CostInputs(), d)["gross"]) < 1e-12
    assert fx.analyse_parity(m).direction == "none"


def test_inconsistent_input_is_flagged():
    # USD has the higher rate but the forward shows USD at a PREMIUM -> must be flagged
    m = fx.MarketInputs("USD/JPY", 91, 160.0, 161.0, 0.038, 0.0105)
    flags = fx.analyse_parity(m).flags
    assert any("INCONSISTENT" in f for f in flags)
    assert any("RED FLAG" in f for f in flags)


def test_costs_never_help():
    m = fx.MarketInputs("EUR/USD", 91, 1.16, 1.1650, 0.022, 0.038)
    wf = fx.cost_waterfall(m, fx.CostInputs(0.0001, 0.0002, 0.0025, 0.001, 0.02, 0.04, 0.5), "borrow_quote")
    vals = [v for _, v in wf]
    assert all(a >= b - 1e-15 for a, b in zip(vals, vals[1:]))


def test_asymmetric_tax_can_flip_but_symmetric_cannot():
    m, c, country, ent = fx.build_examples()[0]
    r = fx.run(m, c, country, ent)
    assert r["net_pu"] > 0
    verdicts = dict(r["verdict_tax"])
    assert any(v == "Profitable after tax" for v in verdicts.values())
    assert any(v == "TAX FLIPS IT TO A LOSS" for v in verdicts.values())


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
