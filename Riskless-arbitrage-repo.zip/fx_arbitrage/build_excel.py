"""Build FX_Arbitrage_Engine.xlsx — every number below the input block is a live formula."""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.comments import Comment

import fx_arbitrage as fx

wb = Workbook()
FONT = "Arial"
BLUE = Font(name=FONT, color="0000FF")
BLACK = Font(name=FONT, color="000000")
GREEN = Font(name=FONT, color="008000")
BOLD = Font(name=FONT, bold=True)
HDR = Font(name=FONT, bold=True, color="FFFFFF")
HDR_FILL = PatternFill("solid", fgColor="1F3864")
SEC_FILL = PatternFill("solid", fgColor="D9E1F2")
YELLOW = PatternFill("solid", fgColor="FFFF00")
thin = Side(style="thin", color="999999")

# ---------------------------------------------------------------- TaxRegimes sheet
tr = wb.active
tr.title = "TaxRegimes"
heads = ["Key", "Jurisdiction", "Treatment", "Rate on interest pool", "Rate on FX pool",
         "Borrow cost deductible (1/0)", "Pools offset each other (1/0)", "Notes (PLACEHOLDER — verify)"]
for j, h in enumerate(heads, 1):
    c = tr.cell(row=1, column=j, value=h); c.font = HDR; c.fill = HDR_FILL
    c.alignment = Alignment(wrap_text=True, vertical="top")
keys = []
row = 2
for country, entities in [("India", ["individual", "company"]), ("US", ["individual"]),
                          ("Europe", ["individual"]), ("South Korea", ["individual"]),
                          ("Australia", ["individual"])]:
    for ent in entities:
        for k, t in enumerate(fx.tax_treatments(country, ent), 1):
            key = f"{t.jurisdiction.split(' (')[0]}-{ent[:3]}-{k}"
            keys.append((key, t))
            vals = [key, t.jurisdiction, t.label, t.rate_income, t.rate_fx,
                    int(t.interest_deductible), int(t.cross_offset), t.notes]
            for j, v in enumerate(vals, 1):
                c = tr.cell(row=row, column=j, value=v)
                c.font = BLUE if j >= 4 else BLACK
                c.alignment = Alignment(wrap_text=True, vertical="top")
                if j in (4, 5):
                    c.number_format = "0.000%"
            row += 1
last_tax_row = row - 1
tr.cell(row=row + 1, column=1, value=fx.TAX_DISCLAIMER).font = Font(name=FONT, italic=True)
for col, w in zip("ABCDEFGH", [14, 24, 60, 12, 12, 14, 14, 90]):
    tr.column_dimensions[col].width = w

# ---------------------------------------------------------------- Engine sheet
ws = wb.create_sheet("Engine", 0)
ws.column_dimensions["A"].width = 46
for col in "BCDE":
    ws.column_dimensions[col].width = 20
ws.column_dimensions["F"].width = 70

examples = fx.build_examples()
COLS = ["B", "C", "D", "E"]
r = 1
ws["A1"] = "FX Arbitrage Intelligence Engine — Covered Interest Rate Parity (CIRP)"
ws["A1"].font = Font(name=FONT, bold=True, size=14)
ws["A2"] = ("Blue = input (edit these). Black = formula. Pairs quoted BASE/QUOTE = units of QUOTE per 1 BASE. "
            "'Domestic' in the CFA formula = QUOTE currency.")
ws["A2"].font = Font(name=FONT, italic=True)


def section(row, title):
    ws.cell(row=row, column=1, value=title).font = HDR
    for j in range(1, 7):
        ws.cell(row=row, column=j).fill = HDR_FILL


def label(row, text, note=None):
    c = ws.cell(row=row, column=1, value=text); c.font = BOLD
    if note:
        ws.cell(row=row, column=6, value=note).font = Font(name=FONT, italic=True, color="555555")


def put(row, col, value, fmt=None, inp=False, fill=None):
    c = ws[f"{col}{row}"]
    c.value = value
    c.font = BLUE if inp else BLACK
    if fmt:
        c.number_format = fmt
    if fill:
        c.fill = fill
    return c


# ---- Inputs
section(4, "1. MARKET INPUTS (per pair)")
R = {}
rows = [("pair", "Pair (BASE/QUOTE)"), ("base", "Base currency"), ("quote", "Quote currency"),
        ("days", "Tenor (days)"), ("spot", "S  — spot mid (quote per base)"),
        ("fwd", "F_market — outright forward mid"),
        ("ib", "i_base  (foreign rate, annualised)"), ("iq", "i_quote (domestic rate, annualised)"),
        ("bb", "Day-count basis, base ccy (360/365)"), ("bq", "Day-count basis, quote ccy (360/365)"),
        ("N", "Notional borrowed (in borrowed ccy)"), ("src", "Source / note")]
rr = 5
for key, text in rows:
    R[key] = rr; label(rr, text); rr += 1
for col, (m, c, country, ent) in zip(COLS, examples):
    put(R["pair"], col, m.pair, inp=True, fill=YELLOW)
    put(R["base"], col, f'=LEFT({col}{R["pair"]},FIND("/",{col}{R["pair"]})-1)')
    put(R["quote"], col, f'=MID({col}{R["pair"]},FIND("/",{col}{R["pair"]})+1,3)')
    put(R["days"], col, m.days, inp=True)
    put(R["spot"], col, m.spot_mid, "0.000000", inp=True, fill=YELLOW)
    put(R["fwd"], col, m.fwd_mid, "0.000000", inp=True, fill=YELLOW)
    put(R["ib"], col, m.i_base, "0.0000%", inp=True)
    put(R["iq"], col, m.i_quote, "0.0000%", inp=True)
    put(R["bb"], col, m.basis_base, inp=True)
    put(R["bq"], col, m.basis_quote, inp=True)
    put(R["N"], col, 1_000_000, "#,##0", inp=True)
    put(R["src"], col, m.note, inp=True)
ws.cell(row=R["src"], column=6, value=("Illustrative Sep-2026 levels: spot from published month-open levels; 3M rates set near "
    "policy rates (Fed 3.75, ECB 2.25, BoE 3.75, BoJ 1.00, RBI 5.25). Market forwards are CONSTRUCTED = "
    "CIRP fair + a deliberate mispricing. Not live quotes.")).font = Font(name=FONT, italic=True, color="555555")
ws.cell(row=R["src"], column=6).alignment = Alignment(wrap_text=True, vertical="top")

# ---- Costs
rr += 1
section(rr, "2. REAL-WORLD COST INPUTS"); rr += 1
crows = [("ss", "Spot bid-ask spread (full width, price units)"), ("fs", "Forward bid-ask spread (full width)"),
         ("bs", "Borrowing spread over risk-free (annualised)"), ("ds", "Deposit haircut below risk-free (annualised)"),
         ("mp", "Forward initial margin (% of notional)"), ("mf", "Funding cost of margin (annualised)"),
         ("fee", "Brokerage / settlement fee (bps of notional)")]
for key, text in crows:
    R[key] = rr; label(rr, text); rr += 1
for col, (m, c, country, ent) in zip(COLS, examples):
    put(R["ss"], col, c.spot_spread, "0.00000", inp=True)
    put(R["fs"], col, c.fwd_spread, "0.00000", inp=True)
    put(R["bs"], col, c.borrow_spread, "0.00%", inp=True)
    put(R["ds"], col, c.deposit_spread, "0.00%", inp=True)
    put(R["mp"], col, c.margin_pct, "0.0%", inp=True)
    put(R["mf"], col, c.margin_funding, "0.00%", inp=True)
    put(R["fee"], col, c.fee_bps, "0.0", inp=True)

# ---- CIRP
rr += 1
section(rr, "3. CIRP — IMPLIED FORWARD vs MARKET  [CFA L1: F = S(1+i_d·τ)/(1+i_f·τ)]"); rr += 1
prows = [("tb", "τ_base = days / basis_base"), ("tq", "τ_quote = days / basis_quote"),
         ("ffair", "F_fair = S × (1+i_quote·τq) / (1+i_base·τb)"),
         ("mis", "Mispricing = F_market − F_fair"), ("misbp", "Mispricing, annualised bp on spot"),
         ("pm", "Fwd premium/discount on base, MARKET = F_mkt/S − 1"),
         ("pf", "Fwd premium/discount on base, FAIR = F_fair/S − 1"),
         ("dir", "Theoretical direction"), ("bccy", "Currency borrowed"), ("dtxt", "Trade description"),
         ("chk1", "Sanity: parity direction consistent?"), ("chk2", "Sanity: gap size plausible?")]
for key, text in prows:
    R[key] = rr; label(rr, text); rr += 1
for col in COLS:
    g = lambda k: f"{col}{R[k]}"
    put(R["tb"], col, f"={g('days')}/{g('bb')}", "0.000000")
    put(R["tq"], col, f"={g('days')}/{g('bq')}", "0.000000")
    put(R["ffair"], col, f"={g('spot')}*(1+{g('iq')}*{g('tq')})/(1+{g('ib')}*{g('tb')})", "0.000000")
    put(R["mis"], col, f"={g('fwd')}-{g('ffair')}", "+0.000000;-0.000000;0")
    put(R["misbp"], col, f"={g('mis')}/{g('spot')}*{g('bq')}/{g('days')}*10000", "+0.00;-0.00;0.00")
    put(R["pm"], col, f"={g('fwd')}/{g('spot')}-1", "+0.00000%;-0.00000%")
    put(R["pf"], col, f"={g('ffair')}/{g('spot')}-1", "+0.00000%;-0.00000%")
    put(R["dir"], col, f'=IF(ABS({g("misbp")})<=0.01,"none",IF({g("mis")}>0,"borrow_quote","borrow_base"))')
    put(R["bccy"], col, f'=IF({g("dir")}="borrow_base",{g("base")},{g("quote")})')
    put(R["dtxt"], col, f'=IF({g("dir")}="none","At parity — no trade",IF({g("dir")}="borrow_quote",'
                        f'"Fwd sells "&{g("base")}&" too DEAR: borrow "&{g("quote")}&", buy "&{g("base")}&" spot, invest, SELL "&{g("base")}&" fwd",'
                        f'"Fwd sells "&{g("base")}&" too CHEAP: borrow "&{g("base")}&", sell spot, invest "&{g("quote")}&", BUY "&{g("base")}&" fwd"))')
    put(R["chk1"], col, f'=IF(AND({g("ib")}>{g("iq")},{g("fwd")}>{g("spot")}),"INCONSISTENT: higher-rate base at fwd PREMIUM",'
                        f'IF(AND({g("ib")}<{g("iq")},{g("fwd")}<{g("spot")}),"INCONSISTENT: lower-rate base at fwd DISCOUNT","OK"))')
    put(R["chk2"], col, f'=IF(ABS({g("misbp")})>25,"RED FLAG: >25bp — suspect data / capital controls","OK")')
ws.cell(row=R["dir"], column=6, value="Direction computed on mid-to-mid gap; if 'none', the trade block below still evaluates the borrow_quote leg so costs are visible.").font = Font(name=FONT, italic=True, color="555555")

# ---- Trade block (all frictions on)
rr += 1
section(rr, "4. EXECUTE THE ROUND TRIP WITH ALL FRICTIONS  (Profit = Final amount − Amount owed)"); rr += 1
trows = [("d", "Leg evaluated"), ("sbid", "Spot bid"), ("sask", "Spot ask"), ("fbid", "Forward bid"), ("fask", "Forward ask"),
         ("ipay", "Interest paid on borrowing"), ("owed", "Amount owed at maturity"),
         ("conv", "Principal converted at spot (other ccy)"), ("drate", "Deposit rate earned"), ("dtau", "τ of deposit leg"),
         ("iearn", "Interest earned (converted at forward)"), ("fxp", "FX result on principal (spot→forward)"),
         ("final", "Final amount"), ("gross", "Gross profit = Final − Owed"),
         ("mc", "Margin funding cost"), ("fees", "Fees"), ("net", "Net profit = Gross − Trading costs"),
         ("netbp", "Net, annualised bp on notional"), ("ident", "Check: FX + interest earned − interest paid − gross (=0)")]
for key, text in trows:
    R[key] = rr; label(rr, text); rr += 1
for col in COLS:
    g = lambda k: f"{col}{R[k]}"
    Q = f'{g("d")}="borrow_quote"'
    put(R["d"], col, f'=IF({g("dir")}="borrow_base","borrow_base","borrow_quote")')
    put(R["sbid"], col, f"={g('spot')}-{g('ss')}/2", "0.000000")
    put(R["sask"], col, f"={g('spot')}+{g('ss')}/2", "0.000000")
    put(R["fbid"], col, f"={g('fwd')}-{g('fs')}/2", "0.000000")
    put(R["fask"], col, f"={g('fwd')}+{g('fs')}/2", "0.000000")
    put(R["ipay"], col, f"=IF({Q},{g('N')}*({g('iq')}+{g('bs')})*{g('tq')},{g('N')}*({g('ib')}+{g('bs')})*{g('tb')})", "#,##0.00")
    put(R["owed"], col, f"={g('N')}+{g('ipay')}", "#,##0.00")
    put(R["conv"], col, f"=IF({Q},{g('N')}/{g('sask')},{g('N')}*{g('sbid')})", "#,##0.00")
    put(R["drate"], col, f"=IF({Q},{g('ib')}-{g('ds')},{g('iq')}-{g('ds')})", "0.0000%")
    put(R["dtau"], col, f"=IF({Q},{g('tb')},{g('tq')})", "0.000000")
    put(R["iearn"], col, f"=IF({Q},{g('conv')}*{g('drate')}*{g('dtau')}*{g('fbid')},{g('conv')}*{g('drate')}*{g('dtau')}/{g('fask')})", "#,##0.00")
    put(R["fxp"], col, f"=IF({Q},{g('conv')}*{g('fbid')}-{g('N')},{g('conv')}/{g('fask')}-{g('N')})", "+#,##0.00;-#,##0.00")
    put(R["final"], col, f"=IF({Q},{g('conv')}*(1+{g('drate')}*{g('dtau')})*{g('fbid')},{g('conv')}*(1+{g('drate')}*{g('dtau')})/{g('fask')})", "#,##0.00")
    put(R["gross"], col, f"={g('final')}-{g('owed')}", "#,##0.00;(#,##0.00);-")
    put(R["mc"], col, f"={g('N')}*{g('mp')}*{g('mf')}*IF({Q},{g('tq')},{g('tb')})", "#,##0.00")
    put(R["fees"], col, f"={g('N')}*{g('fee')}/10000", "#,##0.00")
    put(R["net"], col, f"={g('gross')}-{g('mc')}-{g('fees')}", "#,##0.00;(#,##0.00);-").font = BOLD
    put(R["netbp"], col, f"={g('net')}/{g('N')}*IF({Q},{g('bq')},{g('bb')})/{g('days')}*10000", "+0.00;-0.00")
    put(R["ident"], col, f"=ROUND({g('fxp')}+{g('iearn')}-{g('ipay')}-{g('gross')},6)", "0.000000")

# ---- Waterfall (sequential frictions)
rr += 1
section(rr, "5. COST WATERFALL — each friction switched on in turn (per notional borrowed)"); rr += 1
wf_labels = [("w0", "Gross arbitrage profit (mid, risk-free)", (0, 0, 0, 0, 0)),
             ("w1", "less spot bid-ask", (1, 0, 0, 0, 0)),
             ("w2", "less forward bid-ask", (1, 1, 0, 0, 0)),
             ("w3", "less borrow/lend spread", (1, 1, 1, 0, 0)),
             ("w4", "less forward margin funding", (1, 1, 1, 1, 0)),
             ("w5", "less brokerage / settlement fees", (1, 1, 1, 1, 1))]
for key, text, _ in wf_labels:
    R[key] = rr; label(rr, text); rr += 1
R["wchk"] = rr; label(rr, "Check: last waterfall row − net profit (=0)"); rr += 1


def wf_formula(col, s, f, rte, mg, fe):
    """Net profit with frictions selectively on (flags are literal 0/1)."""
    g = lambda k: f"{col}{R[k]}"
    Q = f'{g("d")}="borrow_quote"'
    sb = f"({g('spot')}-{s}*{g('ss')}/2)"; sa = f"({g('spot')}+{s}*{g('ss')}/2)"
    fb = f"({g('fwd')}-{f}*{g('fs')}/2)"; fa = f"({g('fwd')}+{f}*{g('fs')}/2)"
    bq = f"({g('iq')}+{rte}*{g('bs')})"; bb = f"({g('ib')}+{rte}*{g('bs')})"
    dq = f"({g('iq')}-{rte}*{g('ds')})"; db = f"({g('ib')}-{rte}*{g('ds')})"
    final = (f"IF({Q},{g('N')}/{sa}*(1+{db}*{g('tb')})*{fb},"
             f"{g('N')}*{sb}*(1+{dq}*{g('tq')})/{fa})")
    owed = f"IF({Q},{g('N')}*(1+{bq}*{g('tq')}),{g('N')}*(1+{bb}*{g('tb')}))"
    margin = f"{mg}*{g('N')}*{g('mp')}*{g('mf')}*IF({Q},{g('tq')},{g('tb')})"
    fee = f"{fe}*{g('N')}*{g('fee')}/10000"
    return f"={final}-{owed}-{margin}-{fee}"


for col in COLS:
    for key, _, flags in wf_labels:
        put(R[key], col, wf_formula(col, *flags), "#,##0.00;(#,##0.00);-")
    put(R["wchk"], col, f"=ROUND({col}{R['w5']}-{col}{R['net']},6)", "0.000000")

# ---- Verdict + tax
rr += 1
section(rr, "6. VERDICTS — after cost, then after tax (regimes from 'TaxRegimes' sheet; PLACEHOLDER rates)"); rr += 1
R["vcost"] = rr; label(rr, "Verdict after costs"); rr += 1
for col in COLS:
    g = lambda k: f"{col}{R[k]}"
    put(R["vcost"], col, f'=IF(ABS({g("w0")})<=0.000001,"No arbitrage",IF({g("net")}>0.000001,"Arbitrage survives costs","Arbitrage exists but is cost-negative"))').font = BOLD

dv = DataValidation(type="list", formula1=f"=TaxRegimes!$A$2:$A${last_tax_row}", allow_blank=False)
ws.add_data_validation(dv)
default_keys = {"EUR/USD": ("US-ind-1", "US-ind-2"), "GBP/USD": ("Europe-ind-1", "Europe-ind-2"),
                "USD/JPY": ("South Korea-ind-1", "South Korea-ind-2"), "USD/INR": ("India-ind-1", "India-ind-2")}
for block in ("A", "B"):
    rr += 1
    label(rr, f"Tax regime {block}  (dropdown → TaxRegimes!A)"); R[f"key{block}"] = rr; rr += 1
    sub = [("jur", "Jurisdiction"), ("lab", "Treatment"), ("ri", "Rate on interest pool"), ("rf", "Rate on FX pool"),
           ("ded", "Borrow cost deductible?"), ("off", "Pools offset each other?"),
           ("dedn", "Deductions allowed (interest paid + margin + fees)"), ("ipool", "Interest pool = interest earned − deductions"),
           ("fpool", "FX pool = FX result on principal"), ("tax", "Tax due"), ("at", "After-tax profit"), ("vt", "After-tax verdict")]
    for key, text in sub:
        R[f"{key}{block}"] = rr; label(rr, text); rr += 1
    for col, (m, _, _, _) in zip(COLS, examples):
        g = lambda k: f"{col}{R[k]}"
        kc = g(f"key{block}")
        c = put(R[f"key{block}"], col, default_keys[m.pair][0 if block == "A" else 1], inp=True, fill=YELLOW)
        dv.add(c)
        lk = lambda n: f"INDEX(TaxRegimes!${get_column_letter(n)}$2:${get_column_letter(n)}${last_tax_row},MATCH({kc},TaxRegimes!$A$2:$A${last_tax_row},0))"
        put(R[f"jur{block}"], col, f"={lk(2)}").font = GREEN
        put(R[f"lab{block}"], col, f"={lk(3)}").font = GREEN
        ws[f"{col}{R[f'lab{block}']}"].alignment = Alignment(wrap_text=True, vertical="top")
        put(R[f"ri{block}"], col, f"={lk(4)}", "0.000%").font = GREEN
        put(R[f"rf{block}"], col, f"={lk(5)}", "0.000%").font = GREEN
        put(R[f"ded{block}"], col, f"={lk(6)}").font = GREEN
        put(R[f"off{block}"], col, f"={lk(7)}").font = GREEN
        ri, rf, ded, off = g(f"ri{block}"), g(f"rf{block}"), g(f"ded{block}"), g(f"off{block}")
        put(R[f"dedn{block}"], col, f"=IF({ded}=1,{g('ipay')}+{g('mc')}+{g('fees')},0)", "#,##0.00")
        put(R[f"ipool{block}"], col, f"={g('iearn')}-{g(f'dedn{block}')}", "+#,##0.00;-#,##0.00")
        put(R[f"fpool{block}"], col, f"={g('fxp')}", "+#,##0.00;-#,##0.00")
        ip, fp = g(f"ipool{block}"), g(f"fpool{block}")
        put(R[f"tax{block}"], col,
            f"=IF({off}=1,IF(AND({fp}>=0,{ip}>=0),{ri}*{ip}+{rf}*{fp},IF({fp}<0,{ri},{rf})*MAX({ip}+{fp},0)),"
            f"{ri}*MAX({ip},0)+{rf}*MAX({fp},0))", "#,##0.00")
        put(R[f"at{block}"], col, f"={g('net')}-{g(f'tax{block}')}", "#,##0.00;(#,##0.00);-").font = BOLD
        put(R[f"vt{block}"], col,
            f'=IF({g("net")}<=0.000001,"Cost-negative before tax",IF({g(f"at{block}")}>0.000001,"Profitable after tax","TAX FLIPS IT TO A LOSS"))').font = BOLD
ws.cell(row=R["taxA"], column=6, value=("Tax = interest pool × rate_i + FX pool × rate_fx. If pools may offset, a loss in one shelters "
    "the other; if not, the loss is trapped and the gain is taxed in full — this is what can flip a small pre-tax profit.")).font = Font(name=FONT, italic=True, color="555555")
ws.cell(row=R["taxA"], column=6).alignment = Alignment(wrap_text=True, vertical="top")

# ---- Final waterfall summary
rr += 1
section(rr, "7. WATERFALL SUMMARY (per notional borrowed)"); rr += 1
for key, text, src in [("s1", "Gross arbitrage profit", "w0"), ("s2", "After-cost profit", "net"),
                       ("s3", "After-tax profit — regime A", "atA"), ("s4", "After-tax profit — regime B", "atB")]:
    R[key] = rr; label(rr, text)
    for col in COLS:
        put(rr, col, f"={col}{R[src]}", "#,##0.00;(#,##0.00);-").font = BOLD
    rr += 1
for key, text, src in [("s5", "Verdict after costs", "vcost"), ("s6", "Verdict after tax — A", "vtA"), ("s7", "Verdict after tax — B", "vtB"),
                       ("s8", "Sanity flag", "chk2")]:
    R[key] = rr; label(rr, text)
    for col in COLS:
        put(rr, col, f"={col}{R[src]}")
    rr += 1

ws.freeze_panes = "B5"
for row in ws.iter_rows(min_row=1, max_row=rr):
    for c in row:
        if c.font.name != FONT:
            c.font = Font(name=FONT, bold=c.font.bold, italic=c.font.italic, color=c.font.color, size=c.font.size)

# ---------------------------------------------------------------- README
rd = wb.create_sheet("README")
rd.column_dimensions["A"].width = 120
lines = [
    ("FX Arbitrage Intelligence Engine — Covered Interest Rate Parity", True),
    ("", False),
    ("WHAT IT TESTS: Covered IRP only. The forward contract locks the future conversion, so there is no FX risk. It is NOT Uncovered IRP (expected spot).", False),
    ("", False),
    ("FORMULAS (CFA Level 1, price/base quoting: S = units of QUOTE per 1 BASE; 'domestic' = quote currency)", True),
    ("  F_fair = S × (1 + i_domestic·τ_d) / (1 + i_foreign·τ_f)     τ = days / day-count basis", False),
    ("  Mispricing = F_market − F_fair          (annualised bp = mispricing / S × basis / days × 10,000)", False),
    ("  Forward premium/discount = F / S − 1     (> 0: base at premium; the LOWER-rate currency trades at a premium)", False),
    ("  Profit = Final amount − Amount owed;   Net profit = Gross arbitrage profit − Trading costs", False),
    ("", False),
    ("DAY-COUNT: the curriculum uses one τ = days/360 for both legs. Markets use ACT/360 for USD, EUR, JPY and ACT/365 for GBP, INR — set both bases to 360 to reproduce the textbook.", False),
    ("", False),
    ("DIRECTION RULE: F_market > F_fair → forward sells the base too dear → borrow QUOTE, buy base spot, invest base, SELL base forward.", False),
    ("                F_market < F_fair → borrow BASE, sell base spot, invest quote, BUY base forward.", False),
    ("", False),
    ("COST LAYER: bid/ask applied on the correct side of each leg (spot ask when buying base, forward bid when selling base, etc.), borrow at i + spread, deposit at i − haircut, margin funded for τ, flat fee. Section 5 switches each on in turn.", False),
    ("", False),
    ("TAX LAYER: gross profit is decomposed into interest earned, interest paid, and the FX result on principal, because regimes tax these differently. Regime table in 'TaxRegimes' — every rate is an ILLUSTRATIVE PLACEHOLDER. Verify before use.", False),
    ("", False),
    ("SANITY CHECKS: higher-rate currency must trade at a forward discount (flag if violated); a mid-to-mid gap above 25 bp annualised is treated as a data problem or a capital-control artefact, not a free lunch.", False),
    ("", False),
    ("Cross-checked against fx_arbitrage.py (Python) — identical inputs produce identical outputs to the cent.", False),
]
for i, (t, b) in enumerate(lines, 1):
    c = rd.cell(row=i, column=1, value=t); c.font = Font(name=FONT, bold=b); c.alignment = Alignment(wrap_text=True)

wb.save("FX_Arbitrage_Engine.xlsx")
print("rows:", rr, "tax rows:", last_tax_row)
import json; json.dump(R, open("/tmp/claude-0/-home-claude/a04d3635-ef81-51e3-82ad-93b2ebc77f08/scratchpad/rowmap.json", "w"))
