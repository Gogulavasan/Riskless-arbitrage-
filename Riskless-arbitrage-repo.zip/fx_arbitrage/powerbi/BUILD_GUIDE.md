# Power BI dashboard — "Arbitrage Insights" (neon)

A `.pbix` is a binary Power BI Desktop file, so this kit gives you everything that goes *into* one: data, theme, measures and the page layout. Build time in Power BI Desktop: ~20 minutes. The HTML mock-up (`neon_dashboard.html`, also published as an artifact) shows the target look.

## 1. Load the data

`Get data → Text/CSV` for each file in `powerbi/data/`:

| Table | Grain | Used by |
|---|---|---|
| `pairs_summary` | 1 row per pair | KPI tiles, verdict, direction, sanity |
| `cost_waterfall` | 6 rows per pair | Waterfall visual |
| `tax_results` | 2 regimes per pair | Tax comparison bars |
| `tax_regimes` | 11 regimes | Regime reference table |
| `breakeven_grid` | 31 gaps × 6 spreads per pair | Break-even heat-map |
| `trace_steps` | 7 steps per pair | "Show your work" strip |

Model view: create `Pairs = DISTINCT(pairs_summary[Pair])` (Modeling → New table) and relate `Pairs[Pair]` one-to-many to `Pair` in every other table. Use `Pairs[Pair]` for the slicer. Regenerate the CSVs any time with `python powerbi/export_powerbi_data.py`.

## 2. Apply the theme

`View → Themes → Browse for themes → theme_neon_arbitrage.json`. Page background goes near-black (#0B0F1A), visuals get dark cards with a cyan glow, data colours cycle cyan → magenta → yellow → violet.

## 3. Add the measures

Modeling → New measure, paste each line from `measures.dax` (one measure per line; the name is left of `=`).

## 4. Page layout (16:9, mirrors the "Executive Insights" style you sent)

```
┌────────────────────────────────────────────────────────────────────────────────┐
│ ARBITRAGE INSIGHTS            ① Select a pair [slicer: Pairs]   ② Regime [slicer]│
│ Does covered interest arbitrage survive the real world?                        │
├───────────┬───────────┬───────────┬───────────┬───────────┬────────────────────┤
│ Spot      │ F_fair    │ F_market  │ Mispricing│ Net bp    │  VERDICT           │
│ 1.160000  │ 1.164666  │ 1.164966  │ +10.24 bp │ +0.32 bp  │  Survives costs    │
│ (card)    │ (card)    │ (card)    │ (card)    │ (card)    │  (card, Verdict Colour)│
├───────────────────────────────────────┬────────────────────────────────────────┤
│ How much does each friction erode?    │ Does tax flip it?                      │
│ WATERFALL: Category=Step (sort        │ CLUSTERED BAR: Axis=Treatment,         │
│ StepOrder), Y=Waterfall Erosion,      │ Values=After Tax Profit, Net Profit;   │
│ show "Gross" as first bar via         │ data-colour by Tax Verdict Colour      │
│ Breakdown=none                        │                                        │
├───────────────────────────────────────┼────────────────────────────────────────┤
│ Where is the break-even frontier?     │ Show your work                         │
│ MATRIX: Rows=MispricingBpAnn,         │ TABLE: trace_steps (StepOrder, Step,   │
│ Cols=BorrowSpreadBp, Values=Frontier  │ Value) + text cards with Formula CIRP, │
│ Net, background colour = Frontier     │ Formula Premium, Formula Profit        │
│ Colour (conditional formatting→field) │ + Sanity Flag card (Sanity Colour)     │
└───────────────────────────────────────┴────────────────────────────────────────┘
```

Conditional colours: on any card, Format → Callout value → Colour → *fx* → Format style "Field value" → pick the matching `… Colour` measure.

## 5. Fancy ideas that work well in Power BI (all data already exported)

* **Break-even frontier heat-map** — the matrix above. The cyan region is "free money"; its left edge is `Breakeven bp`. This is the single most instructive visual: it shows why a 10 bp mispricing is real money for a bank (5 bp funding spread) and a loss for everyone else.
* **Sanity gauge** — gauge of `ABS(Mispricing bp ann)` with max 50 and a target at 25: anything past the target is "suspect your data", exactly the rule in the engine.
* **Tax-flip badge** — card with `Tax Flips Count`, red glow when > 0. The EUR/USD §1256 case lights it up.
* **Bookmarks** — one bookmark per pair so a "story" button walks through survives → no arbitrage → cost-negative → red-flagged.
* **Tooltip page** — a small page bound to `trace_steps` so hovering any pair's bar shows S → F_fair → F_market → gap → net.
* **Drill-through** to a regime detail page showing the `tax_regimes[Notes]` text — keeps the "placeholder, verify" caveat one click away.
