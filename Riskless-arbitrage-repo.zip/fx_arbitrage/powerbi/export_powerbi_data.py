"""Export the engine's outputs as tidy CSVs for Power BI.  Run from the repo root:
    python powerbi/export_powerbi_data.py
Writes powerbi/data/*.csv  (one fact table per visual, plus a sensitivity grid)."""
import csv, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fx_arbitrage as fx

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUT, exist_ok=True)
N = 1_000_000.0


def w(name, rows, header):
    with open(os.path.join(OUT, name), "w", newline="", encoding="utf-8") as f:
        cw = csv.writer(f); cw.writerow(header); cw.writerows(rows)
    print("wrote", name, len(rows), "rows")


summary, waterfall, taxes, steps = [], [], [], []
for m, c, country, ent in fx.build_examples():
    r = fx.run(m, c, country, ent, N)
    p, f = r["parity"], r["full"]
    summary.append([m.pair, m.base, m.quote, m.days, m.spot_mid, m.fwd_mid, m.i_base, m.i_quote,
                    m.basis_base, m.basis_quote, p.f_fair, p.mispricing, p.mispricing_bps_ann,
                    p.premium_market, p.premium_fair, p.direction, r["borrowed_ccy"], N,
                    r["gross_pu"] * N, r["net_pu"] * N,
                    fx.annualise_bps(r["net_pu"], m.days, m.basis_quote if r["direction"] == "borrow_quote" else m.basis_base),
                    f["final"] * N, f["owed"] * N, f["i_earn"] * N, f["i_pay"] * N, f["fx_principal"] * N,
                    r["verdict_cost"], "; ".join(p.flags) if p.flags else "OK", country, m.note])
    prev = None
    for i, (label, v) in enumerate(r["waterfall"]):
        waterfall.append([m.pair, i, label, v * N, 0.0 if prev is None else (v - prev) * N, r["borrowed_ccy"]])
        prev = v
    for t, tx, at in r["tax"]:
        taxes.append([m.pair, t.jurisdiction, t.label, t.rate_income, t.rate_fx, int(t.interest_deductible),
                      int(t.cross_offset), tx * N, at * N,
                      dict(r["verdict_tax"])[t.label], r["borrowed_ccy"]])
    # step-by-step trace table (for a "show your work" visual)
    for i, (k, v) in enumerate([("S (spot)", m.spot_mid), ("F_fair (CIRP)", p.f_fair), ("F_market", m.fwd_mid),
                                ("Mispricing", p.mispricing), ("Gross profit", r["gross_pu"] * N),
                                ("Net after costs", r["net_pu"] * N), ("After tax (regime A)", r["tax"][0][2] * N)]):
        steps.append([m.pair, i, k, v])

w("pairs_summary.csv", summary,
  ["Pair", "Base", "Quote", "Days", "Spot", "FwdMarket", "iBase", "iQuote", "BasisBase", "BasisQuote", "FwdFair",
   "Mispricing", "MispricingBpAnn", "PremiumMarket", "PremiumFair", "Direction", "BorrowedCcy", "Notional",
   "GrossProfit", "NetProfit", "NetBpAnn", "FinalAmount", "AmountOwed", "InterestEarned", "InterestPaid",
   "FxPrincipal", "VerdictCost", "SanityFlags", "TaxCountry", "Note"])
w("cost_waterfall.csv", waterfall, ["Pair", "StepOrder", "Step", "CumulativeProfit", "Erosion", "Ccy"])
w("tax_results.csv", taxes, ["Pair", "Jurisdiction", "Treatment", "RateInterest", "RateFx", "BorrowDeductible",
                             "PoolsOffset", "TaxDue", "AfterTaxProfit", "VerdictTax", "Ccy"])
w("trace_steps.csv", steps, ["Pair", "StepOrder", "Step", "Value"])

# Tax regime dimension
regs = []
for country, ents in [("India", ["individual", "company"]), ("US", ["individual"]), ("Europe", ["individual"]),
                      ("South Korea", ["individual"]), ("Australia", ["individual"])]:
    for e in ents:
        for t in fx.tax_treatments(country, e):
            regs.append([t.jurisdiction, e, t.label, t.rate_income, t.rate_fx, int(t.interest_deductible), int(t.cross_offset), t.notes])
w("tax_regimes.csv", regs, ["Jurisdiction", "Entity", "Treatment", "RateInterest", "RateFx", "BorrowDeductible", "PoolsOffset", "Notes"])

# Break-even frontier: net profit as mispricing (bp annualised) x borrow/lend spread, per pair.
grid = []
for m, c, country, ent in fx.build_examples():
    for gap_bp in range(-30, 31, 2):
        for spread_bp in (0, 5, 10, 25, 50, 100):
            mm = fx.MarketInputs(m.pair, m.days, m.spot_mid, 0.0, m.i_base, m.i_quote, m.basis_base, m.basis_quote)
            mm.fwd_mid = fx.implied_forward(mm) * (1 + gap_bp / 10_000 * m.days / m.basis_quote)
            cc = fx.CostInputs(c.spot_spread, c.fwd_spread, spread_bp / 10_000, spread_bp / 20_000, c.margin_pct, c.margin_funding, c.fee_bps)
            p = fx.analyse_parity(mm)
            d = p.direction if p.direction != "none" else "borrow_quote"
            net = fx.trade_pnl(mm, cc, d, N)["net"]
            grid.append([m.pair, gap_bp, spread_bp, net, 1 if net > 0 else 0])
w("breakeven_grid.csv", grid, ["Pair", "MispricingBpAnn", "BorrowSpreadBp", "NetProfit", "Survives"])
