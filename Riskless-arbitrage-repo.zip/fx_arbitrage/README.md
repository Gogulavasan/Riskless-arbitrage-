# FX Arbitrage Intelligence Engine — Covered Interest Rate Parity

Detects **Covered Interest Rate Parity (CIRP)** deviations between currency pairs, computes whether a theoretical risk-free (covered interest) arbitrage exists, then tests whether it survives real-world frictions and country-specific tax.

> Covered parity only. The forward contract locks the future conversion, so there is no exchange-rate risk. This is **not** Uncovered IRP (expected future spot, not risk-free).

**Website (GitHub Pages, served from `docs/`):** https://gogulavasan.github.io/Riskless-arbitrage-/

| Page | What |
|---|---|
| `index.html` | Home — formulas, the four worked cases computed live, links |
| `invest.html` | **Investment calculator** — capital in, pair, cost profile, country, entity → gross / after-cost / after-tax, capital needed for a target, country ranking, pair × country return matrix |
| `calculator.html` | CIRP calculator — full step-by-step trace with two tax regimes, flags inconsistent inputs |
| `dashboard.html` | Neon dashboard — KPI tiles, friction waterfall, tax flip, break-even frontier |
| `powerbi.html` | Power BI page — embeds the published report (paste the Publish-to-web URL), kit links |
| `engine.js`, `theme.css` | One copy of the maths and one theme shared by every page |

Enable: repo **Settings → Pages → Source: Deploy from a branch → `main` / `/docs`**.

## Formulas (CFA Level 1, price/base quoting)

A pair `BASE/QUOTE` is quoted as units of QUOTE per 1 BASE; the QUOTE currency is the CFA "domestic" currency.

| | |
|---|---|
| No-arbitrage forward | `F = S × (1 + i_domestic·τ_d) / (1 + i_foreign·τ_f)`, `τ = days / basis` |
| Mispricing | `F_market − F_fair` (also shown annualised in bp) |
| Forward premium / discount | `F / S − 1` (the lower-rate currency trades at a premium) |
| Arbitrage profit | `Profit = Final amount − Amount owed` |
| Net profit | `Gross arbitrage profit − Trading costs` |

Day-count: the curriculum uses one `τ = days/360` for both legs; markets use ACT/360 (USD, EUR, JPY) and ACT/365 (GBP, INR). Both tools take a basis per currency — set both to 360 to reproduce the textbook.

## What the engine does, in order

1. Ingest spot, market forward, both risk-free rates, tenor, day-count bases.
2. Compute the CIRP implied forward.
3. Compare implied vs market: mispricing in price units and annualised bp; premium/discount both ways.
4. Direction: `F_market > F_fair` → borrow QUOTE, buy base spot, invest base, SELL base forward. `F_market < F_fair` → borrow BASE, sell spot, invest quote, BUY base forward.
5. Cost layer, itemised and switched on one at a time: spot bid-ask · forward bid-ask · borrow/lend spread · forward margin funding · fees. Each leg uses the *correct side* of each quote.
6. Verdict after costs: *Arbitrage survives costs* / *Arbitrage exists but is cost-negative* / *No arbitrage*. Then the tax layer, shown as a waterfall gross → after-cost → after-tax.
7. Sanity checks: a higher-rate currency must trade at a forward discount (inconsistent inputs are flagged, not computed through); a mid-to-mid gap above 25 bp annualised is treated as bad data or a capital-control artefact, not free money.

## Tax layer (illustrative placeholders — verify before use)

Gross profit is decomposed into *interest earned*, *interest paid*, and the *FX result on principal*, because regimes tax the pieces differently. When a regime taxes the profitable leg but ring-fences the loss-making leg, a marginally profitable trade turns into an after-tax loss — the engine calls that out explicitly.

Jurisdictions: India (individual / LLP / company, s.43(5) speculative question), US (§1256 60/40 vs §988 ordinary — both shown), Europe (generic Germany-style until a member state is specified), South Korea (withholding + global-aggregation threshold), Australia (Div 775 ordinary income vs CGT).

## Files

| File | What |
|---|---|
| `fx_arbitrage.py` | Engine + four worked examples. `python fx_arbitrage.py` prints the full step-by-step trace. |
| `test_fx_arbitrage.py` | Unit tests (textbook CIRP, direction, identity, inconsistency flags, tax flip). |
| `FX_Arbitrage_Engine.xlsx` | Same model in live formulas: `Engine` sheet (4 pairs side by side, dropdown tax regimes), `TaxRegimes`, `README`. Rebuilt by `build_excel.py`; every output cross-checks against Python to the cent. |
| `docs/` | The website above (static, no build step). |
| `powerbi/` | Power BI kit: model output as CSVs, neon theme JSON, DAX measures, page layout guide. |

## Worked examples (Sep-2026 illustrative levels, 3M tenor)

Spot from published month-open levels, 3M rates set near policy rates (Fed 3.75, ECB 2.25, BoE 3.75, BoJ 1.00, RBI 5.25). Market forwards are *constructed* = fair forward + a deliberate mispricing, so each case lands in a different verdict bucket. Not live quotes.

| Pair | Mispricing | Cost profile | After costs | After tax |
|---|---|---|---|---|
| EUR/USD | +3 pips (+10.2 bp) | bank / dealer | survives (+0.32 bp) | §988 profitable; **§1256 flips it to a loss** |
| GBP/USD | 0 | retail | no arbitrage | — |
| USD/JPY | −0.03 (−7.4 bp) | retail | cost-negative | — |
| USD/INR | +0.25 (+105.7 bp, red-flagged) | onshore | cost-negative | — |
